<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Extra extends Model
{
    protected $table='extra';
    public $timestamps = false;
}
