<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Domains extends Model
{
    protected $table='domains';
    public $timestamps = false;
}
